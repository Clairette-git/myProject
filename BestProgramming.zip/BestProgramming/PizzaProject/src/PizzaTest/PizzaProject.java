/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package PizzaTest;

import Domain.PizzaConfig;
import java.util.Scanner;

/**
 *
 * @author Clairette
 */
public class PizzaProject {

    /**
     * @param args the command line arguments
     */
   StringBuilder build = new StringBuilder();
   
    public static void main(String[] args) {
 // calling menue method
        new PizzaProject().menu();

    }
    
  PizzaConfig conf = new PizzaConfig();
   PizzaConfig pizza = new PizzaConfig();
 
    public void menu() {
        System.out.println(" PizzAn Restaurant\n");
        double totalPrice =0.0;
        int count = 0;
                Scanner scanner = new Scanner(System.in);

        System.out.println("Enter  the Name of the Pizza You want:");
        
        String selected = scanner.nextLine();
        pizza.setName(selected );
        System.out.println("Thanks for choosing: " + pizza.getName());
        System.out.println(" The size of " + pizza.getName() + "\n");
        System.out.println("Press 1: for Large =6500Rwf\n");
        System.out.println("Press 2: for Medium =4500Rwf\n");
        System.out.println("Press 3: for Small =3000Rwf\n");
        double price=0.0;
        int size = scanner.nextInt();

        switch (size) {
            case 1:
                pizza.setSize("Large");
                pizza.setBaseprice(6500);
                price=6500;
                break;

            case 2:
                pizza.setSize("Medium");
                pizza.setBaseprice(4500);
                price=4500;
                break;

            case 3:
                pizza.setSize("Small");
                pizza.setBaseprice(3000);
                price=3000;
                break;
        }


        //Delivery checking
        boolean terminate = false;
        while(!terminate){
        System.out.println("Do you want to Delivery? \n  YES / NO"+ " :"+"There is Charges for Delivering: 500rwf" );
        String delivery = scanner.next();

        if (delivery.toUpperCase().equals("YES")) {
              
            totalPrice = price+500;
            double amount =500;
            pizza.setDelivery(amount);
           System.out.println("Total Price = "+totalPrice);
           terminate =true;
        }

        else if (delivery.toUpperCase().equals("NO")) {
         
            totalPrice = price;
            double amount =0.0;
            System.out.println("TotalPrice = "+totalPrice);
            pizza.setDelivery(amount);
            terminate =true;
        }else{
            System.err.println("No match.");
            terminate = false;
        }
        }
        
        
        meatOrVegetableOptionSet(pizza,totalPrice);
    }

    public void meatOrVegetableOptionSet(PizzaConfig config,double totalPrice) {

        boolean terminated = false;
        Scanner scan = new Scanner(System.in);

        String category = "";

        while (!terminated) {

            System.out.println("Press 1 For Meat.  Press 2 For Vegetable");

            switch (scan.nextInt()) {

                case 1:
                    String[] meatChoosen = meat();
                    category = "meat";
                    terminated = true;
                    config.setOptionsets(category, meatChoosen, totalPrice);
                case 2:
                    String[] vegetableChoosen = vegetable();
                    category = "vegetable";
                    terminated = true;
                    config.setOptionsets(category,vegetableChoosen, totalPrice);
                    
                    //Here we call requestedOrdering method to dispay pizza requested by customer 
               requestedOrdering();
            }

        }
    }

    // Method for MeatOptions
    public String[] meat() {
        String meat[] = new String[12];
        boolean terminated = false;

        Scanner scan = new Scanner(System.in);

        while (!terminated) {
            System.out.println(" Press 1 Be2f"+"\n"+" 2 Fish"+"\n"+" 3 vegetables"+"\n");
            switch (scan.nextInt()) {
                case 1:
                    build.append("Beef").append(" ");
                    break;
                case 2:
                     build.append("Fish").append(" ");
                    break;
               case 3:

                    terminated = true;
                    break;
            }

        }
        return meat;

    }
    // Method for VegetableOptions


    public String[] vegetable() {
        int size=1;
        String vegetable[] = new String[12];
        int i = 0;
        boolean terminated = false;

        Scanner scan = new Scanner(System.in);
        while (!terminated) {
            System.out.println("Press 1 Lettuce"+"\n"+" 2 Union"+"\n"+" 3 for Tomatoes"+"\n"+"  4 BACK"+"\n"+" 5 Finish ");
            switch (scan.nextInt()) {
                case 1:
                    build.append("Mushroom").append(" ");
                    break;
                case 2:
                    build.append("Union").append(" ");
                    break;
                case 3:
                 build.append("Tomatoes").append(" ");
                    break;
                case 4:
                    meat();
                    break;

                case 5:

                    terminated = true;
                    break;
            }
        }
        return vegetable;
    }

    //Complete Customer Order :1
    
    public void requestedOrdering()
    {
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("THANK YOU FOR ORDERING MELLION PIZZA");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("This is your Requested Pizza Order:");
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("Name: "+pizza.getName());
        System.out.println("Size: "+pizza.getSize());
                System.out.println("Price: "+pizza.getBaseprice());
        double basePrice = pizza.getBaseprice();
        System.out.println("Delivering Charge:"+pizza.getDelivery());
        Double deliver = pizza.getDelivery();
        System.out.println("This "+pizza.getName() +" Of"+build);
        double totalAmount = basePrice + deliver;
        System.out.println("Total : "+totalAmount);
        System.out.println("~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~");
        System.out.println("-----------Please Wait for your delivery-----------!!");
        
    
    }

    
}
